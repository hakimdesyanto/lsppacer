$(document).ready(function(){
	$('.wysihtml5').wysihtml5();
});
